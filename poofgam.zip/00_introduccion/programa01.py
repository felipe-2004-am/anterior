"""
     Nombre: Felipe Gregorio AM
     Matricula:1723110135
     Grupo: TI21
     Fecha: 18/01/2024
     Descripción: Se da a conocer el valor de nombre
"""

class A:              #define una clase de nombre A
    matricula= None     #Declara  la variable matricula
    nombre= None        #Declara  la variable nombre
    
objectA=A()           #Genera una instancia de la clase A

print(objectA.nombre) #Imprime el valor de nombre 
